class ApiStore {
  set jwt(jwtString) {
    this.jwtString = jwtString;
  }

  get jwt() {
    return this.jwtString;
  }

  set uid(userId) {
    this.userId = userId;
  }

  get uid() {
    return this.userId;
  }
}

export default new ApiStore();
