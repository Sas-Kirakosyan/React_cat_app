import { createSlice } from "@reduxjs/toolkit";
import { fetchImages } from "../api/api";

const initialState = {
  images: [],
  page: 1,
  isLoading: false,
  error: null,
};

const imagesSlice = createSlice({
  name: "images",
  initialState,
  reducers: {
    loading: (state) => {
      state.isLoading = true;
    },
    success: (state, { payload }) => {
      state.isLoading = false;
      state.error = false;
      state.images = payload ?? [];
    },
    error: (state, { payload }) => {
      state.isLoading = false;
      state.error = payload;
    },
  },
});

export const { loading, success, error } = imagesSlice.actions;

export const getImages = (page = 1, categoryID = "") => {
  return async (dispatch) => {
    dispatch(loading());
    try {
      dispatch(success(await fetchImages(page, categoryID)));
    } catch (error) {
      dispatch(error(error.toString()));
    }
  };
};

export default imagesSlice.reducer;
